package realtime.videocall.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AyaneApplication {

	public static void main(String[] args) {
		SpringApplication.run(AyaneApplication.class, args);
	}

}
