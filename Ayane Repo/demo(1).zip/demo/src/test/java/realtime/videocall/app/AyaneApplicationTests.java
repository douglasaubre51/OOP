package realtime.videocall.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AyaneApplicationTests {

	@Test
	void contextLoads() {
	}

}
